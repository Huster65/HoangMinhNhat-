export const allTypeProduct = [
    {
      name: "iphone",
      img: "https://cdn.tgdd.vn/Brand/1/logo-iphone-220x48.png",
    },
    {
      name: "samsung",
      img: "https://cdn.tgdd.vn/Brand/1/Samsung42-b_25.jpg",
    },
    {
      name: "oppo",
      img: "https://cdn.tgdd.vn/Brand/1/OPPO42-b_5.jpg",
    },
    {
      name: "vivo",
      img: "https://cdn.tgdd.vn/Brand/1/Vivo42-b_50.jpg",
    },
    {
      name: "xiaomi",
      img: "https://cdn.tgdd.vn/Brand/1/logo-xiaomi-220x48-5.png",
    },
    {
      name: "realme",
      img: "https://cdn.tgdd.vn/Brand/1/Realme42-b_37.png",
    },
    {
      name: "vsmart",
      img: "https://cdn.tgdd.vn/Brand/1/Vsmart42-b_40.png",
    },
    {
      name: "nokia",
      img: "https://cdn.tgdd.vn/Brand/1/Nokia42-b_21.jpg",
    },
  ];