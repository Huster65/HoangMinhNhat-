import React from 'react';
import Signup from '../components/Signup/Signup'
function SignupPage(props) {
    return (
        <div>
            <Signup></Signup>
        </div>
    );
}

export default SignupPage;